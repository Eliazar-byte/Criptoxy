//! # Bitcoin Output Script Descriptor (BOSD)
//!
//! This module implements a BOSD parser and validator.
//!
//! The main type is [`Descriptor`].
//! Check this crate's top-level documentation for the
//! specification and rationale.

use core::fmt;
use std::{
    fmt::{Display, Formatter},
    str::FromStr,
};

use hex::{DisplayHex, FromHex};
use secp256k1::XOnlyPublicKey;

use crate::error::DescriptorError;

/// `OP_RETURN` type tag.
pub(crate) const OP_RETURN_TYPE_TAG: u8 = 0;

/// Maximum length of `OP_RETURN` payload.
///
/// Bitcoin Core's `datacarriersize` default is 100,000 bytes for the entire script.
/// See: <https://github.com/bitcoin/bitcoin/blob/v30.0/src/policy/policy.cpp#L146>
///
/// Bitcoin Core's `MAX_STANDARD_TX_WEIGHT` is 400,000 weight units.
/// For non-segwit transactions: max size = 400,000 / 4 = 100,000 bytes.
/// See: <https://github.com/bitcoin/bitcoin/blob/v28.0/src/policy/policy.h#L27>
///
/// A valid transaction requires at least one input. The minimum overhead for a
/// transaction with a single OP_RETURN output spending a bare `OP_TRUE` output is:
///
/// - Version: 4 bytes
/// - Input count (`varint=1`): 1 byte
/// - Input (prevout + empty scriptSig + sequence): 41 bytes
/// - Output count (`varint=1`): 1 byte
/// - Output value: 8 bytes
/// - ScriptPubKey length (varint, for scripts `> 65_535`): 5 bytes
/// - `OP_RETURN` + `OP_PUSHDATA4` + 4-byte length: 6 bytes
/// - Locktime: 4 bytes
/// - Total overhead: 70 bytes
///
/// Therefore: max payload = 100,000 - 70 = 99,930 bytes
pub const MAX_OP_RETURN_LEN: usize = 99_930;

/// `P2PKH` type tag.
pub(crate) const P2PKH_TYPE_TAG: u8 = 1;

/// Exact length of P2PKH payload.
pub const P2PKH_LEN: usize = 20;

/// `P2SH` type tag.
pub(crate) const P2SH_TYPE_TAG: u8 = 2;

/// Exact length of P2SH payload.
pub const P2SH_LEN: usize = 20;

/// `P2WPKH`/`P2WSH` type tag.
pub(crate) const P2WPKH_P2WSH_TYPE_TAG: u8 = 3;

/// Exact length of P2WPKH payload.
pub const P2WPKH_LEN: usize = 20;

/// Exact length of P2WSH payload.
pub const P2WSH_LEN: usize = 32;

/// `P2A`/`P2TR` type tag.
pub(crate) const P2TR_TYPE_TAG: u8 = 4;

/// Exact length of `P2A` payload.
pub const P2A_LEN: usize = 0;

/// The exact witness program data bytes for P2A (Pay-to-Anchor) per BIP 433.
///
/// P2A is defined as the scriptPubKey `OP_1 OP_PUSH2 <0x4e73>` (hex: `51 02 4e 73`).
/// This constant contains just the 2-byte program data `[0x4e, 0x73]`, which is what
/// `WitnessProgram::program().as_bytes()` returns for a P2A output.
pub const P2A_PROGRAM_BYTES: [u8; 2] = [0x4e, 0x73];

/// Exact length of P2TR payload.
pub const P2TR_LEN: usize = 32;

/// A Bitcoin Output Script Descriptor (BOSD).
///
/// This is a compact binary format consisting of
/// a `type_tag` that represents a ScriptPubKey that can be
/// relayed by any node in the Bitcoin network,
/// due to standardness requirements.
///
/// See [the Bitcoin developer guide on Transactions](https://developer.bitcoin.org/devguide/transactions.html)
/// for more information on standardness.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
#[repr(C)]
pub struct Descriptor {
    /// The type of the descriptor.
    type_tag: DescriptorType,

    /// The actual underlying data.
    payload: Vec<u8>,
}

impl Descriptor {
    /// Constructs a new [`Descriptor`] from a byte slice.
    ///
    /// Users are advised to use the `new_*` methods whenever possible.
    pub fn from_bytes(bytes: &[u8]) -> Result<Self, DescriptorError> {
        // Extract the type tag (which must exist) and the payload
        let (&type_tag, payload) = bytes.split_first().ok_or(DescriptorError::MissingTypeTag)?;

        // Validate the payload length against the type
        match type_tag {
            // OP_RETURN must be at most 100KB.
            OP_RETURN_TYPE_TAG => {
                let payload_len = payload.len();
                if payload_len > MAX_OP_RETURN_LEN {
                    Err(DescriptorError::InvalidPayloadLength(payload_len))
                } else {
                    Ok(Self {
                        type_tag: DescriptorType::OpReturn,
                        payload: payload.to_vec(),
                    })
                }
            }
            // P2PKH and P2SH must be exactly 20 bytes.
            P2PKH_TYPE_TAG => {
                let payload_len = payload.len();
                if payload_len != P2PKH_LEN {
                    Err(DescriptorError::InvalidPayloadLength(payload_len))
                } else {
                    Ok(Self {
                        type_tag: DescriptorType::P2pkh,
                        payload: payload.to_vec(),
                    })
                }
            }
            P2SH_TYPE_TAG => {
                let payload_len = payload.len();
                if payload_len != P2SH_LEN {
                    Err(DescriptorError::InvalidPayloadLength(payload_len))
                } else {
                    Ok(Self {
                        type_tag: DescriptorType::P2sh,
                        payload: payload.to_vec(),
                    })
                }
            }
            // P2WPKH must be exactly 20 bytes, and P2SH must be exactly 32 bytes.
            P2WPKH_P2WSH_TYPE_TAG => {
                let payload_len = payload.len();
                match payload_len {
                    P2WPKH_LEN => Ok(Self {
                        type_tag: DescriptorType::P2wpkh,
                        payload: payload.to_vec(),
                    }),
                    P2WSH_LEN => Ok(Self {
                        type_tag: DescriptorType::P2wsh,
                        payload: payload.to_vec(),
                    }),
                    _ => Err(DescriptorError::InvalidPayloadLength(payload_len)),
                }
            }
            // P2A must be exactly 0 bytes, and P2TR must be exactly 32 bytes.
            P2TR_TYPE_TAG => {
                let payload_len = payload.len();
                match payload_len {
                    P2A_LEN => Ok(Self {
                        type_tag: DescriptorType::P2a,
                        payload: payload.to_vec(),
                    }),
                    P2TR_LEN => {
                        validate_xonly_pubkey(payload)?;
                        Ok(Self {
                            type_tag: DescriptorType::P2tr,
                            payload: payload.to_vec(),
                        })
                    }
                    _ => Err(DescriptorError::InvalidPayloadLength(payload_len)),
                }
            }
            _ => Err(DescriptorError::InvalidDescriptorType(type_tag)),
        }
    }

    /// Constructs a new [`Descriptor`] from a byte [`Vec`].
    ///
    /// Users are advised to use the `new_*` methods whenever possible.
    pub fn from_vec(bytes: Vec<u8>) -> Result<Self, DescriptorError> {
        Self::from_bytes(&bytes)
    }

    /// Constructs a new [`Descriptor`] from an `OP_RETURN` payload.
    ///
    /// The payload is expected to be at most 100KB.
    ///
    /// # Example
    ///
    /// ```
    /// # use bitcoin_bosd::{Descriptor, DescriptorType};
    /// let payload = b"hello world";
    /// let desc = Descriptor::new_op_return(payload).expect("valid payload that is at most 100KB");
    /// # assert_eq!(desc.type_tag(), DescriptorType::OpReturn);
    /// # assert_eq!(desc.payload(), b"hello world");
    /// ```
    pub fn new_op_return(payload: &[u8]) -> Result<Self, DescriptorError> {
        let type_tag = DescriptorType::OpReturn;
        let payload_len = payload.len();
        if payload_len > MAX_OP_RETURN_LEN {
            Err(DescriptorError::InvalidPayloadLength(payload_len))
        } else {
            Ok(Self {
                type_tag,
                payload: payload.to_vec(),
            })
        }
    }

    /// Constructs a new [`Descriptor`] from a P2PKH payload.
    ///
    /// The payload is expected to be a valid 20-byte hash.
    ///
    /// # Example
    ///
    /// ```
    /// # use bitcoin_bosd::{Descriptor, DescriptorType, descriptor::P2PKH_LEN};
    /// let payload = [0u8; P2PKH_LEN]; // all zeros, don't use in production
    /// let desc = Descriptor::new_p2pkh(&payload);
    /// # assert_eq!(desc.type_tag(), DescriptorType::P2pkh);
    /// # assert_eq!(desc.payload(), [0u8; P2PKH_LEN]);
    /// ```
    pub fn new_p2pkh(payload: &[u8; P2PKH_LEN]) -> Self {
        let type_tag = DescriptorType::P2pkh;
        Self {
            type_tag,
            payload: payload.to_vec(),
        }
    }

    /// Constructs a new [`Descriptor`] from a P2SH payload.
    ///
    /// The payload is expected to be a valid 20-byte hash.
    ///
    /// # Example
    ///
    /// ```
    /// # use bitcoin_bosd::{Descriptor, DescriptorType, descriptor::P2SH_LEN};
    /// let payload = [0u8; P2SH_LEN]; // all zeros, don't use in production
    /// let desc = Descriptor::new_p2sh(&payload);
    /// # assert_eq!(desc.type_tag(), DescriptorType::P2sh);
    /// # assert_eq!(desc.payload(), [0u8; P2SH_LEN]);
    /// ```
    pub fn new_p2sh(payload: &[u8; P2SH_LEN]) -> Self {
        let type_tag = DescriptorType::P2sh;
        Self {
            type_tag,
            payload: payload.to_vec(),
        }
    }

    /// Constructs a new [`Descriptor`] from a P2WPKH payload.
    ///
    /// The payload is expected to be a valid 20-byte hash.
    ///
    /// # Example
    ///
    /// ```
    /// # use bitcoin_bosd::{Descriptor, DescriptorType, descriptor::P2WPKH_LEN};
    /// let payload = [0u8; P2WPKH_LEN]; // all zeros, don't use in production
    /// let desc = Descriptor::new_p2wpkh(&payload);
    /// # assert_eq!(desc.type_tag(), DescriptorType::P2wpkh);
    /// # assert_eq!(desc.payload(), [0u8; P2WPKH_LEN]);
    /// ```
    pub fn new_p2wpkh(payload: &[u8; P2WPKH_LEN]) -> Self {
        let type_tag = DescriptorType::P2wpkh;
        Self {
            type_tag,
            payload: payload.to_vec(),
        }
    }

    /// Constructs a new [`Descriptor`] from a P2WSH payload.
    ///
    /// The payload is expected to be a valid 32-byte hash.
    ///
    /// # Example
    ///
    /// ```
    /// # use bitcoin_bosd::{Descriptor, DescriptorType, descriptor::P2WSH_LEN};
    /// let payload = [0u8; P2WSH_LEN]; // all zeros, don't use in production
    /// let desc = Descriptor::new_p2wsh(&payload);
    /// # assert_eq!(desc.type_tag(), DescriptorType::P2wsh);
    /// # assert_eq!(desc.payload(), [0u8; P2WSH_LEN]);
    /// ```
    pub fn new_p2wsh(payload: &[u8; P2WSH_LEN]) -> Self {
        let type_tag = DescriptorType::P2wsh;
        Self {
            type_tag,
            payload: payload.to_vec(),
        }
    }

    /// Constructs a new [`Descriptor`] from an empty P2A payload.
    ///
    /// # Example
    ///
    /// ```
    /// # use bitcoin_bosd::{Descriptor, DescriptorType, descriptor::P2A_LEN};
    /// let payload = [0u8; P2A_LEN]; // empty payload
    /// let desc = Descriptor::new_p2a(&payload);
    /// # assert_eq!(desc.type_tag(), DescriptorType::P2a);
    /// # assert_eq!(desc.payload(), [0u8; P2A_LEN]);
    /// ```
    pub fn new_p2a(payload: &[u8; P2A_LEN]) -> Self {
        let type_tag = DescriptorType::P2a;

        Self {
            type_tag,
            payload: payload.to_vec(),
        }
    }

    /// Constructs a new [`Descriptor`] from a P2TR payload.
    ///
    /// The payload is expected to be a valid 32-byte X-only public key.
    /// This function will validate this key for you, and return an error if validation fails.
    ///
    /// # Example
    ///
    /// ```
    /// # use bitcoin_bosd::{Descriptor, DescriptorType, descriptor::P2TR_LEN};
    /// let payload = [2u8; P2TR_LEN]; // valid X-only public key, but don't use in production
    /// let desc = Descriptor::new_p2tr(&payload).expect("valid X-only public key");
    /// # assert_eq!(desc.type_tag(), DescriptorType::P2tr);
    /// # assert_eq!(desc.payload(), [2u8; P2TR_LEN]);
    /// ```
    pub fn new_p2tr(payload: &[u8; P2TR_LEN]) -> Result<Self, DescriptorError> {
        validate_xonly_pubkey(payload)?;
        Ok(Self {
            type_tag: DescriptorType::P2tr,
            payload: payload.to_vec(),
        })
    }

    /// Returns the bytes representation of the descriptor.
    ///
    /// That is:
    ///
    /// - 1-byte type tag.
    /// - arbitrary-sized payload.
    pub fn to_bytes(&self) -> Vec<u8> {
        let mut bytes = Vec::with_capacity(1 + self.payload.len());
        bytes.push(self.type_tag.to_u8());
        bytes.extend_from_slice(&self.payload);
        bytes
    }

    /// Generates fixed bytes of payload of length specified by the generic parameter.
    ///
    /// # Notes
    ///
    /// - This method is intended for internal use and relies on the caller ensuring that the
    ///   payload's length matches the size `B`.
    pub(crate) fn to_fixed_payload_bytes<const B: usize>(&self) -> [u8; B] {
        debug_assert_eq!(self.payload().len(), B);
        let mut bytes = [0u8; B];
        bytes[..].copy_from_slice(self.payload());
        bytes
    }

    /// Returns the type tag of the descriptor.
    pub fn type_tag(&self) -> DescriptorType {
        self.type_tag
    }

    /// Returns the payload of the descriptor.
    ///
    /// # Warning
    ///
    /// It is not advisable to use this method.
    /// Instead, try to parse it either as a Bitcoin address
    /// by using [`Descriptor::to_address`] in the case of an address,
    /// or as a Bitcoin script by using [`Descriptor::to_script`] in
    /// the case of an `OP_RETURN` payload.
    pub fn payload(&self) -> &[u8] {
        self.payload.as_slice()
    }
}

impl Display for Descriptor {
    fn fmt(&self, f: &mut Formatter) -> std::fmt::Result {
        let type_tag = self.type_tag().to_u8();
        write!(f, "{}{}", [type_tag].as_hex(), self.payload.as_hex())
    }
}

impl FromStr for Descriptor {
    type Err = DescriptorError;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let bytes = Vec::from_hex(s)?;
        Self::from_bytes(&bytes)
    }
}

/// The type tag of a [`Descriptor`].
///
/// This is the first byte of the payload.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[non_exhaustive] // Might need more in the future.
pub enum DescriptorType {
    /// `OP_RETURN` payload.
    OpReturn,

    /// P2PKH hash.
    ///
    /// It is a 20-byte hash of a public key,
    /// that is first hashed with SHA-256,
    /// followed by RIPEMD-160.
    P2pkh,

    /// P2SH hash.
    ///
    /// It is a 20-byte hash of a custom locking script,
    /// that is first hashed with SHA-256,
    /// followed by RIPEMD-160.
    P2sh,

    /// P2WPKH hash.
    ///
    /// It is a 20-byte hash of a public key,
    /// that is first hashed with SHA-256,
    /// followed by RIPEMD-160.
    P2wpkh,

    /// P2WSH hash.
    ///
    /// It is a 32-byte hash of a custom locking script
    /// hashed with SHA-256.
    P2wsh,

    ///  P2A.
    ///
    /// An anchor's descriptor has no payload.
    P2a,

    /// P2TR X-only public key.
    ///
    /// It is a 32-byte public key.
    /// The key might be tweaked by a Merkle root hash
    /// that represents the underlying taptree of script
    /// spending conditions.
    P2tr,
}

impl DescriptorType {
    /// Returns the type tag as a byte.
    pub fn to_u8(self) -> u8 {
        match self {
            DescriptorType::OpReturn => 0,
            DescriptorType::P2pkh => 1,
            DescriptorType::P2sh => 2,
            DescriptorType::P2wpkh => 3,
            DescriptorType::P2wsh => 3,
            DescriptorType::P2a => 4,
            DescriptorType::P2tr => 4,
        }
    }
}

impl Display for DescriptorType {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            DescriptorType::OpReturn => write!(f, "OP_RETURN"),
            DescriptorType::P2pkh => write!(f, "P2PKH"),
            DescriptorType::P2sh => write!(f, "P2SH"),
            DescriptorType::P2wpkh => write!(f, "P2WPKH"),
            DescriptorType::P2wsh => write!(f, "P2WSH"),
            DescriptorType::P2a => write!(f, "P2A"),
            DescriptorType::P2tr => write!(f, "P2TR"),
        }
    }
}

/// Validates that a 32-byte slice is a valid X-only public key on the secp256k1 curve.
fn validate_xonly_pubkey(payload: &[u8]) -> Result<(), DescriptorError> {
    XOnlyPublicKey::from_slice(payload)
        .map(|_| ())
        .map_err(|_| DescriptorError::InvalidXOnlyPublicKey)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[cfg(test)]
    mod proptest_tests {
        use proptest::prelude::*;

        use super::*;

        proptest! {
            /// Test that any valid `OP_RETURN` payload (0-100KB) roundtrips correctly.
            #[test]
            fn op_return_roundtrip_property(data in prop::collection::vec(any::<u8>(), 0..=MAX_OP_RETURN_LEN)) {
                if data.len() <= MAX_OP_RETURN_LEN {
                    let mut bytes = vec![0u8; data.len() + 1];
                    bytes[0] = 0; // OP_RETURN type tag
                    bytes[1..].copy_from_slice(&data);

                    let descriptor = Descriptor::from_bytes(&bytes).expect("valid OP_RETURN should parse");
                    assert_eq!(descriptor.type_tag(), DescriptorType::OpReturn);
                    assert_eq!(descriptor.payload(), &data);
                    assert_eq!(&descriptor.to_bytes(), &bytes);
                }
            }

            /// Test that `OP_RETURN` payloads larger than 100KB are rejected.
            #[test]
            fn op_return_invalid_size_property(data in prop::collection::vec(any::<u8>(), (MAX_OP_RETURN_LEN + 1)..=(MAX_OP_RETURN_LEN * 2))) {
                let mut bytes = vec![0u8; data.len() + 1];
                bytes[0] = 0; // OP_RETURN type tag
                bytes[1..].copy_from_slice(&data);

                assert!(Descriptor::from_bytes(&bytes).is_err(),
                    "OP_RETURN payload of {} bytes should be rejected", data.len());
            }

            /// Test that exactly 100KB `OP_RETURN` payloads are accepted.
            #[test]
            fn op_return_max_size_property(data in prop::collection::vec(any::<u8>(), MAX_OP_RETURN_LEN..=MAX_OP_RETURN_LEN)) {
                let mut bytes = vec![0u8; data.len() + 1];
                bytes[0] = 0; // OP_RETURN type tag
                bytes[1..].copy_from_slice(&data);

                let descriptor = Descriptor::from_bytes(&bytes).expect("100KB OP_RETURN should be valid");
                assert_eq!(descriptor.type_tag(), DescriptorType::OpReturn);
                assert_eq!(descriptor.payload(), &data);
                assert_eq!(&descriptor.to_bytes(), &bytes);
            }

            /// Test that any valid descriptor roundtrips correctly.
            #[test]
            fn descriptor_roundtrip_property(data in prop::collection::vec(any::<u8>(), 1..=(MAX_OP_RETURN_LEN + 1))) {
                if let Ok(descriptor) = Descriptor::from_bytes(&data) {
                    assert_eq!(&descriptor.to_bytes(), &data);
                }
            }
        }
    }

    #[test]
    fn descriptor_from_bytes() {
        let bytes = [0, 1, 2, 3, 4, 5];
        let descriptor = Descriptor::from_bytes(&bytes).unwrap();
        assert_eq!(descriptor.type_tag(), DescriptorType::OpReturn);
        assert_eq!(descriptor.payload(), &[1, 2, 3, 4, 5]);
    }

    #[test]
    fn descriptor_from_bytes_invalid() {
        // Empty byte slice
        let bytes = [];
        assert!(Descriptor::from_bytes(&bytes).is_err());

        // Only tag type byte
        for type_tag in 0..=u8::MAX {
            let bytes = [type_tag];

            // An empty payload is currently invalid for all types except `OP_RETURN` and `P2TR`
            // with an empty payload.
            match type_tag {
                OP_RETURN_TYPE_TAG => assert!(Descriptor::from_bytes(&bytes).is_ok()),
                P2TR_TYPE_TAG => assert!(Descriptor::from_bytes(&bytes).is_ok()),
                _ => assert!(Descriptor::from_bytes(&bytes).is_err()),
            }
        }

        // Invalid type tag
        let bytes = [5, 1, 2, 3, 4, 5, 6];
        assert!(Descriptor::from_bytes(&bytes).is_err());

        // Invalid payload length
        // OP_RETURN with 100001 bytes (MAX_OP_RETURN_LEN + 1)
        let mut bytes = vec![0; MAX_OP_RETURN_LEN + 2]; // 1 byte type tag + (MAX_OP_RETURN_LEN + 1) bytes payload
        bytes[0] = 0; // OP_RETURN type tag
        assert!(Descriptor::from_bytes(&bytes).is_err());

        // P2PKH with 19 bytes
        let bytes = [1; 20];
        assert!(Descriptor::from_bytes(&bytes).is_err());

        // P2TR with 33 bytes
        let bytes = [4; 34];
        assert!(Descriptor::from_bytes(&bytes).is_err());
    }

    #[test]
    fn descriptor_to_bytes() {
        let original: &[u8; 20] = &[
            0, 99, 104, 97, 114, 108, 101, 121, 32, 108, 111, 118, 101, 115, 32, 104, 101, 105,
            100, 105,
        ];
        let desc = Descriptor::from_str("00636861726c6579206c6f766573206865696469").unwrap();
        let bytes = desc.to_bytes();
        assert_eq!(bytes, original);
    }

    #[test]
    fn descriptor_type() {
        assert_eq!(DescriptorType::OpReturn.to_u8(), 0);
        assert_eq!(DescriptorType::P2pkh.to_u8(), 1);
        assert_eq!(DescriptorType::P2sh.to_u8(), 2);
        assert_eq!(DescriptorType::P2wpkh.to_u8(), 3);
        assert_eq!(DescriptorType::P2wsh.to_u8(), 3);
        assert_eq!(DescriptorType::P2a.to_u8(), 4);
        assert_eq!(DescriptorType::P2tr.to_u8(), 4);
    }

    #[test]
    fn from_str() {
        // OP_RETURN in hex string replacing the 6a (`OP_RETURN`)
        // for a 0x00 (type_tag) byte for `OP_RETURN`.
        // Source: https://bitcoin.stackexchange.com/a/29555
        //         and transaction 8bae12b5f4c088d940733dcd1455efc6a3a69cf9340e17a981286d3778615684
        let s = "00636861726c6579206c6f766573206865696469";
        let desc = Descriptor::from_str(s).unwrap();
        assert_eq!(desc.type_tag(), DescriptorType::OpReturn);
        assert_eq!(desc.payload(), b"charley loves heidi");

        // P2PKH
        // Using 0x01 (type_tag) and a 20-byte hash
        // Source: transaction 8bae12b5f4c088d940733dcd1455efc6a3a69cf9340e17a981286d3778615684
        // Corresponds to address `1HnhWpkMHMjgt167kvgcPyurMmsCQ2WPgg`
        let s = "01b8268ce4d481413c4e848ff353cd16104291c45b";
        let desc = Descriptor::from_str(s).unwrap();
        assert_eq!(desc.type_tag(), DescriptorType::P2pkh);
        assert_eq!(
            desc.payload(),
            Vec::from_hex("b8268ce4d481413c4e848ff353cd16104291c45b").unwrap()
        );

        // P2SH
        // Using 0x02 (type_tag) and a 20-byte hash
        // Source: transaction a0f1aaa2fb4582c89e0511df0374a5a2833bf95f7314f4a51b55b7b71e90ce0f
        // Corresponds to address `3CK4fEwbMP7heJarmU4eqA3sMbVJyEnU3V`
        let s = "02748284390f9e263a4b766a75d0633c50426eb875";
        let desc = Descriptor::from_str(s).unwrap();
        assert_eq!(desc.type_tag(), DescriptorType::P2sh);
        assert_eq!(
            desc.payload(),
            Vec::from_hex("748284390f9e263a4b766a75d0633c50426eb875").unwrap()
        );

        // P2WPKH
        // Using 0x03 (type_tag) and a 20-byte hash
        // Source: transaction 7c53ba0f1fc65f021749cac6a9c163e499fcb2e539b08c040802be55c33d32fe
        // Corresponds to address `bc1qvugyzunmnq5y8alrmdrxnsh4gts9p9hmvhyd40`
        let s = "03671041727b982843f7e3db4669c2f542e05096fb";
        let desc = Descriptor::from_str(s).unwrap();
        assert_eq!(desc.type_tag(), DescriptorType::P2wpkh);
        assert_eq!(
            desc.payload(),
            Vec::from_hex("671041727b982843f7e3db4669c2f542e05096fb").unwrap()
        );

        // P2WSH
        // Using 0x03 (type_tag) and a 32-byte hash
        // Source: transaction fbf3517516ebdf03358a9ef8eb3569f96ac561c162524e37e9088eb13b228849
        // Corresponds to address `bc1qvhu3557twysq2ldn6dut6rmaj3qk04p60h9l79wk4lzgy0ca8mfsnffz65`
        let s = "0365f91a53cb7120057db3d378bd0f7d944167d43a7dcbff15d6afc4823f1d3ed3";
        let desc = Descriptor::from_str(s).unwrap();
        assert_eq!(desc.type_tag(), DescriptorType::P2wsh);
        assert_eq!(
            desc.payload(),
            Vec::from_hex("65f91a53cb7120057db3d378bd0f7d944167d43a7dcbff15d6afc4823f1d3ed3")
                .unwrap()
        );

        // P2A
        // Using 0x04 (type_tag) and a 0-byte payload.
        // Source: transaction c054743f0f3ecfac2cf08c40c7dd36fcb38928cf8e07d179693ca2692d041848
        // Corresponds to address `bc1pfeesrawgf`
        let s = "04";
        let desc = Descriptor::from_str(s).unwrap();
        assert_eq!(desc.type_tag(), DescriptorType::P2a);
        assert_eq!(desc.payload(), Vec::from_hex("").unwrap());

        // P2TR
        // Using 0x04 (type_tag) and a 32-byte hash
        // Source: transaction a7115c7267dbb4aab62b37818d431b784fe731f4d2f9fa0939a9980d581690ec
        // Corresponds to address `bc1ppuxgmd6n4j73wdp688p08a8rte97dkn5n70r2ym6kgsw0v3c5ensrytduf`
        let s = "040f0c8db753acbd17343a39c2f3f4e35e4be6da749f9e35137ab220e7b238a667";
        let desc = Descriptor::from_str(s).unwrap();
        assert_eq!(desc.type_tag(), DescriptorType::P2tr);
        assert_eq!(
            desc.payload(),
            Vec::from_hex("0f0c8db753acbd17343a39c2f3f4e35e4be6da749f9e35137ab220e7b238a667")
                .unwrap()
        );
    }

    #[test]
    fn to_string() {
        let original = "00636861726c6579206c6f766573206865696469";
        let desc = Descriptor::from_bytes(&[
            0, 99, 104, 97, 114, 108, 101, 121, 32, 108, 111, 118, 101, 115, 32, 104, 101, 105,
            100, 105,
        ])
        .unwrap();
        let s = desc.to_string();
        assert_eq!(s, original);
    }

    #[test]
    fn invalid_from_str() {
        // Invalid type tag
        let s = "050000000000000000000000000000000000000000000000000000000000000000";
        assert!(Descriptor::from_str(s).is_err());

        // Invalid payload length
        // OP_RETURN with 100001 bytes (create a hex string with (MAX_OP_RETURN_LEN + 1)*2 hex
        // chars)
        let s = "00".to_string() + &"00".repeat(MAX_OP_RETURN_LEN + 1);
        assert!(Descriptor::from_str(&s).is_err());

        // P2PKH with 19 bytes
        let s = "0100000000000000000000000000000000000000";
        assert!(Descriptor::from_str(s).is_err());

        // P2A with 2 bytes
        let s = "0400";
        assert!(Descriptor::from_str(s).is_err());

        // P2TR with 33 bytes
        let s = "04000000000000000000000000000000000000000000000000000000000000000000";
        assert!(Descriptor::from_str(s).is_err());
    }

    #[test]
    fn test_p2a_fixed_bytes() {
        let desc = Descriptor::from_str("04").unwrap();
        let bytes = desc.to_fixed_payload_bytes::<P2A_LEN>();
        assert_eq!(bytes.len(), P2A_LEN);
    }

    #[test]
    fn test_p2tr_fixed_bytes() {
        let desc = Descriptor::from_str(
            "040f0c8db753acbd17343a39c2f3f4e35e4be6da749f9e35137ab220e7b238a667",
        )
        .unwrap();
        let bytes = desc.to_fixed_payload_bytes::<P2TR_LEN>();
        assert_eq!(bytes.len(), P2TR_LEN);
    }

    #[test]
    fn test_p2pkh_fixed_bytes() {
        let desc = Descriptor::from_str("01b8268ce4d481413c4e848ff353cd16104291c45b").unwrap();
        let bytes = desc.to_fixed_payload_bytes::<P2PKH_LEN>();
        assert_eq!(bytes.len(), P2PKH_LEN);
    }

    #[test]
    fn invalid_new_p2tr() {
        let invalid_payload = [0; P2TR_LEN];
        let result = Descriptor::new_p2tr(&invalid_payload);
        assert!(result.is_err());
        assert_eq!(
            result.err().unwrap(),
            DescriptorError::InvalidXOnlyPublicKey
        );
    }

    #[test]
    fn invalid_p2tr_from_bytes() {
        // P2TR with invalid X-only public key (all zeros is not a valid point on secp256k1)
        let mut bytes = [0u8; 33];
        bytes[0] = P2TR_TYPE_TAG;
        // payload is all zeros, which is invalid
        let result = Descriptor::from_bytes(&bytes);
        assert!(result.is_err());
        assert_eq!(
            result.err().unwrap(),
            DescriptorError::InvalidXOnlyPublicKey
        );
    }

    /// Verify that MAX_OP_RETURN_LEN is correctly calculated to fit within
    /// Bitcoin Core's MAX_STANDARD_TX_WEIGHT for a minimal valid transaction.
    #[cfg(feature = "address")]
    #[test]
    fn max_op_return_fits_in_standard_tx() {
        use bitcoin::{
            absolute::LockTime, blockdata::script::PushBytesBuf, hashes::Hash,
            transaction::Version, Amount, OutPoint, ScriptBuf, Sequence, Transaction, TxIn, TxOut,
            Txid, Witness,
        };

        // Create a minimal valid transaction:
        // - One input spending a bare OP_TRUE output (empty scriptSig)
        // - One OP_RETURN output with MAX_OP_RETURN_LEN bytes
        let tx = Transaction {
            version: Version::ONE,
            lock_time: LockTime::ZERO,
            input: vec![TxIn {
                previous_output: OutPoint {
                    txid: Txid::all_zeros(),
                    vout: 0,
                },
                script_sig: ScriptBuf::new(), // Empty scriptSig (spending bare OP_TRUE)
                sequence: Sequence::MAX,
                witness: Witness::new(),
            }],
            output: vec![TxOut {
                value: Amount::ZERO,
                script_pubkey: ScriptBuf::new_op_return(
                    PushBytesBuf::try_from(vec![0u8; MAX_OP_RETURN_LEN]).unwrap(),
                ),
            }],
        };

        // Verify the transaction weight is within the standard limit
        assert!(
            tx.weight() <= Transaction::MAX_STANDARD_WEIGHT,
            "Transaction with MAX_OP_RETURN_LEN ({}) bytes has weight {} which exceeds MAX_STANDARD_WEIGHT ({})",
            MAX_OP_RETURN_LEN,
            tx.weight(),
            Transaction::MAX_STANDARD_WEIGHT
        );

        // Verify that one more byte would exceed the limit
        let tx_exceeded = Transaction {
            version: Version::ONE,
            lock_time: LockTime::ZERO,
            input: vec![TxIn {
                previous_output: OutPoint {
                    txid: Txid::all_zeros(),
                    vout: 0,
                },
                script_sig: ScriptBuf::new(),
                sequence: Sequence::MAX,
                witness: Witness::new(),
            }],
            output: vec![TxOut {
                value: Amount::ZERO,
                script_pubkey: ScriptBuf::new_op_return(
                    PushBytesBuf::try_from(vec![0u8; MAX_OP_RETURN_LEN + 1]).unwrap(),
                ),
            }],
        };

        assert!(
            tx_exceeded.weight() > Transaction::MAX_STANDARD_WEIGHT,
            "Transaction with MAX_OP_RETURN_LEN + 1 ({}) bytes should exceed MAX_STANDARD_WEIGHT",
            MAX_OP_RETURN_LEN + 1
        );
    }
}
